module TypeProf
  VERSION = "0.15.2"
end
